package crud;

public class CrudUsuario {

    private String login;
    private String nomeUsuario;
    private String senha;
    private String telefone;
    private String email;

    public CrudUsuario() {

    }

    public CrudUsuario(String login, String nomeUsuario, String senha, String telefone, String email) {
        this.login = login;
        this.nomeUsuario = nomeUsuario;
        this.senha = senha;
        this.telefone = telefone;
        this.email = email;
    }

    public String getNomeUsuario() {
        return nomeUsuario;
    }

    public void setNomeUsuario(String nomeUsuario) {
        this.nomeUsuario = nomeUsuario;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getContato() {
        return telefone;
    }

    public void setContato(String contato) {
        this.telefone = contato;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Override
    public String toString() {
        return nomeUsuario;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }
}
