package dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

import crud.CrudEmpres;
import crud.CrudFunc;
import crud.CrudUsuario;

public class DAO extends SQLiteOpenHelper {

    private static final String DATABASE = "database";

    private static final int VERSION = 1;


    public DAO(Context context) {
        super(context, DATABASE, null, VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String dbUsuario = "CREATE TABLE usuarios(id INT PRIMARY KEY AUTOINCREMENT NOT NULL, nome VARCHAR NOT NULL, email VARCHAR NOT NULL, senha VARCHAR NOT NULL,contato VARCHAR NOT NULL);";
        db.execSQL(dbUsuario);
        String dbEmpresa = "CREATE TABLE Empresas(id INT PRIMARY KEY AUTOINCREMENT NOT NULL,nome VARCHAR NOT NULL,senha VARCHAR NOT NULL,contato VARCHAR NOT NULL, email VARCHAR NOT NULL,cnpj VARCHAR NOT NULL);";
        db.execSQL(dbEmpresa);
        String dbFuncionario = "CREATE TABLE funcionarios(id PRIMARY KEY AUTOINCREMENT NOT NULL,nome VARCHAR NOT NULL,senha VARCHAR NOT NULL, email VARCHAR NOT NULL,contato VARCHAR NOT NULL,cpf VARCHAR NOT NULL);";
        db.execSQL(dbFuncionario);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        String dbUsuario = "DROP TABLE IF EXISTS usuarios";
        db.execSQL(dbUsuario);
        String dbEmpresa = "DROP TABLE IF EXISTS empresas";
        db.execSQL(dbEmpresa);
        String dbFuncionario = "DROP TABLE IF EXISTS funcionarios";
        db.execSQL(dbFuncionario);

    }

    public void salvarDados(CrudUsuario usuario, CrudEmpres empresa, CrudFunc funcionario) {
        ContentValues usu = new ContentValues();


        usu.put("nomeUsuario", usuario.getNomeUsuario());
        usu.put("senhaUsuario", usuario.getSenha());
        usu.put("emailUsuario", usuario.getEmail());
        usu.put("contatoUsuario", usuario.getContato());
        usu.put("idUsuario", usuario.getId());

        getWritableDatabase().insert("dbUsuario", null, usu);


        ContentValues empre = new ContentValues();

        empre.put("nomeEmpresa", empresa.getNomeEmpresa());
        empre.put("senhaEmpresa", empresa.getSenha());
        empre.put("contatoEmpresa", empresa.getContato());
        empre.put("emailEmpresa", empresa.getEmail());
        empre.put("cnpjEmpresa", empresa.getCpnj());
        empre.put("idEmpresa", empresa.getId());

        getWritableDatabase().insert("dbEmpresa", null, empre);


        ContentValues func = new ContentValues();

        func.put("nomeFuncionario", funcionario.getNomeFuncionario());
        func.put("senhaFuncionario", funcionario.getSenha());
        func.put("contatoFuncionario", funcionario.getContato());
        func.put("emailFuncionario", funcionario.getEmail());
        func.put("cpfFuncionario", funcionario.getCpf());
        func.put("idFuncionario", funcionario.getId());

        getWritableDatabase().insert("dbFuncioanrio", null, func);

    }

    public void alterarInformaçoesUsuario(CrudUsuario usuario) {

        ContentValues usu = new ContentValues();


        usu.put("nomeUsuario", usuario.getNomeUsuario());
        usu.put("senhaUsuario", usuario.getSenha());
        usu.put("emailUsuario", usuario.getEmail());
        usu.put("contatoUsuario", usuario.getContato());
        usu.put("idUsuario", usuario.getId());

        String[] args = {usuario.getId().toString()};
        getWritableDatabase().update("dbUsuario", usu, "id=?", args);


    }

    public void alterarInformaçoesEmpresa(CrudEmpres empresa) {

        ContentValues empre = new ContentValues();

        empre.put("nomeEmpresa", empresa.getNomeEmpresa());
        empre.put("senhaEmpresa", empresa.getSenha());
        empre.put("contatoEmpresa", empresa.getContato());
        empre.put("emailEmpresa", empresa.getEmail());
        empre.put("cnpjEmpresa", empresa.getCpnj());
        empre.put("idEmpresa", empresa.getId());

        String[] args = {empresa.getId().toString()};
        getWritableDatabase().update("dbEmpresa", empre, "id=?", args);
    }

    public void alterarInformaçoesFuncionario(CrudFunc funcionario) {
        ContentValues func = new ContentValues();

        func.put("nomeFuncionario", funcionario.getNomeFuncionario());
        func.put("senhaFuncionario", funcionario.getSenha());
        func.put("contatoFuncionario", funcionario.getContato());
        func.put("emailFuncionario", funcionario.getEmail());
        func.put("cpfFuncionario", funcionario.getCpf());
        func.put("idFuncionario", funcionario.getId());

        String[] args = {funcionario.getId().toString()};
        getWritableDatabase().update("dbFuncioanrio", func, "id=?", args);


    }

    public void deletarInformacoes(CrudUsuario usuario, CrudEmpres empresa, CrudFunc funcionario) {


        String[] args = {funcionario.getId().toString()};
        getWritableDatabase().delete("dbFuncioanrio", "id=?", args);


        getWritableDatabase().delete("dbEmpresa", "id=?", args);


        getWritableDatabase().delete("dbUsuario", "id=?", args);


    }

    public ArrayList<CrudUsuario> getListaUsuario() {
        String[] columns = {"id", "nomeUsuario", "senha", "contato", "email"};
        Cursor cursor = getWritableDatabase().query("dbUsuario", columns, null, null, null, null, null, null);
        ArrayList<CrudUsuario> mostrarUsuarios = new ArrayList<CrudUsuario>();
        while (cursor.moveToNext()) {
            CrudUsuario usuarios = new CrudUsuario();
            usuarios.setNomeUsuario(cursor.getString(0));
            usuarios.setSenha(cursor.getString(1));
            usuarios.setEmail(cursor.getString(2));
            usuarios.setContato(cursor.getString(3));
            usuarios.setId(cursor.getLong(4));

            mostrarUsuarios.add(usuarios);
        }
        return mostrarUsuarios;
    }

    public ArrayList<CrudEmpres> getListaEmpresa() {
        String[] columns = {"id", "nomeEmpresa", "senha", "contato", "email", "cnpj"};
        Cursor cursor = getWritableDatabase().query("dbEmpresa", columns, null, null, null, null, null, null);
        ArrayList<CrudEmpres> mostrarEmpresas = new ArrayList<CrudEmpres>();

        while (cursor.moveToNext()) {
            CrudEmpres empresas = new CrudEmpres();
            empresas.setNomeEmpresa(cursor.getString(0));
            empresas.setContato(cursor.getString(1));
            empresas.setCpnj(cursor.getString(2));
            empresas.setEmail(cursor.getString(3));
            empresas.setSenha(cursor.getString(4));
            empresas.setId(cursor.getLong(5));
            mostrarEmpresas.add(empresas);
        }
        return mostrarEmpresas;
    }

    public ArrayList<CrudFunc> getListaFuncionario() {
        String[] columns = {"id", "nomeFuncionario", "senha", "cpf", "contato", "email"};
        Cursor cursor = getWritableDatabase().query("dbFuncionario", columns, null, null, null, null, null, null);
        ArrayList<CrudFunc> mostrarFuncionarios = new ArrayList<CrudFunc>();

        while (cursor.moveToNext()) {
            CrudFunc funcionario = new CrudFunc();
            funcionario.setNomeFuncionario(cursor.getString(0));
            funcionario.setSenha(cursor.getString(1));
            funcionario.setEmail(cursor.getString(2));
            funcionario.setContato(cursor.getString(3));
            funcionario.setCpf(cursor.getString(4));
            funcionario.setId(cursor.getLong(5));
            mostrarFuncionarios.add(funcionario);
        }
        return mostrarFuncionarios;
    }

}
