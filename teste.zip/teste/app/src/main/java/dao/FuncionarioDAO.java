package dao;

public class FuncionarioDAO {


}
