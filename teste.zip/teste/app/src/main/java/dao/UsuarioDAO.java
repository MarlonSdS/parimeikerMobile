package dao;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

import crud.CrudUsuario;

public class UsuarioDAO {
    private final String NOME_BANCO = "projeto_crud";
    private final String NOME_TABELA = "usuario";
    private final String COLUNA_LOGIN = "login";
    private final String COLUNA_NOME = "nome_usuario";
    private final String COLUNA_SENHA = "senha";
    private final String COLUNA_EMAIL = "email";
    private final String COLUNA_TELEFONE = "telefone";


    private SQLiteDatabase dtb;

    public UsuarioDAO(Context context) {
        dtb = context.openOrCreateDatabase(NOME_BANCO, Context.MODE_PRIVATE, null);
        dtb.execSQL("CREATE TABLE IF NOT EXISTS " + NOME_TABELA + "(" +
                COLUNA_LOGIN + " VARCHAR(100)," +
                COLUNA_NOME + " VARCHAR(100)," +
                COLUNA_SENHA + " VARCHAR(15)," +
                COLUNA_EMAIL + " VARCHAR(100)," +
                COLUNA_TELEFONE + " VARCHAR(30)" +
                ")");
    }

    public void salvarUsuario(CrudUsuario usuario) {
        dtb.execSQL(String.format("INSERT INTO %s('%s','%s','%s','%s','%s') VALUES ('%s','%s','%s','%s','%s')",
                NOME_TABELA,
                COLUNA_LOGIN,
                COLUNA_NOME,
                COLUNA_SENHA,
                COLUNA_TELEFONE,
                COLUNA_EMAIL,
                usuario.getLogin(),
                usuario.getNomeUsuario(),
                usuario.getSenha(),
                usuario.getContato(),
                usuario.getEmail()
        ));


    }

    public void editarUsuario(CrudUsuario usuario) {
        dtb.execSQL(String.format("UPDATE %s SET %s='%s', %s='%s', %s='%s', %s='%s', %s='%s' WHERE %s='%s'",
                NOME_TABELA,
                COLUNA_LOGIN,
                usuario.getLogin(),
                COLUNA_NOME,
                usuario.getNomeUsuario(),
                COLUNA_SENHA,
                usuario.getSenha(),
                COLUNA_TELEFONE,
                usuario.getContato(),
                COLUNA_EMAIL,
                usuario.getEmail(),
                COLUNA_LOGIN,
                usuario.getLogin()
        ));


    }

    public void excluirUsuario(String login) {

        dtb.execSQL(String.format("DELETE FROM %s WHERE %s='%s'",
                NOME_TABELA,
                COLUNA_LOGIN,
                login));
    }

    public List<CrudUsuario> listarUsuarios() {
        Cursor cursor = dtb.rawQuery("SELECT * FROM " + NOME_TABELA, null);

        int indiceNome = cursor.getColumnIndex(COLUNA_NOME);
        int indiceLogin = cursor.getColumnIndex(COLUNA_LOGIN);
        int indiceSenha = cursor.getColumnIndex(COLUNA_SENHA);
        int indiceEmail = cursor.getColumnIndex(COLUNA_EMAIL);
        int indiceTelefone = cursor.getColumnIndex(COLUNA_TELEFONE);

        List<CrudUsuario> usuarios = new ArrayList<>();
        if (cursor.moveToFirst()) {
            do {
                CrudUsuario usuario = new CrudUsuario(
                        cursor.getString(indiceLogin),
                        cursor.getString(indiceNome),
                        cursor.getString(indiceSenha),
                        cursor.getString(indiceTelefone),
                        cursor.getString(indiceEmail));
                usuarios.add(usuario);
            } while (cursor.moveToNext());
        }

        return usuarios;
    }
}
