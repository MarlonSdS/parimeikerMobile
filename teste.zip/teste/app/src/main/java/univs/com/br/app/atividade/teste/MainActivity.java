package univs.com.br.app.atividade.teste;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {
    private TextView txt_Login, txt_Senha;
    private EditText editTextLogin, editTextSenha;
    private Button btn_Entrar, btn_IrParaCadastro;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        txt_Login = findViewById(R.id.txt_Login);
        txt_Senha = findViewById(R.id.txt_Senha);

        editTextLogin = findViewById(R.id.editTextLogin);
        editTextSenha = findViewById(R.id.editTextSenha);

        btn_Entrar = findViewById(R.id.btn_Entrar);
        btn_IrParaCadastro = findViewById(R.id.btn_IrParaCadastro);


        btn_Entrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (editTextLogin.equals("")) {
                    Toast.makeText(MainActivity.this, "Usuário ou senha inválidos", Toast.LENGTH_LONG).show();

                } else if (editTextSenha.equals("")) {
                    Toast.makeText(MainActivity.this, "Usuário ou senha inválidos", Toast.LENGTH_LONG).show();

                }
            }
        });
        btn_IrParaCadastro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, CadastroUsuario.class);
                startActivity(intent);
            }
        });

    }
}