package univs.com.br.app.atividade.teste;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import crud.CrudUsuario;
import dao.UsuarioDAO;

public class CadastroUsuario extends AppCompatActivity {
    private Button btn_CadastrarUsuario, btn_Voltar, btn_Limpar, btn_Excluir;
    private EditText editTextEmailCadastroUsuario, editTextTelefoneCadastroUsuario, editTextSenhaCadastroUsuario, editTextNomeCadastroUsuario, editTextTextLogin;
    private ListView listaUsuarios;
    private UsuarioDAO dtb;
    private CrudUsuario usuario;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro_usuario);

        dtb = new UsuarioDAO(getApplicationContext());

        btn_CadastrarUsuario = findViewById(R.id.btn_CadastrarUsuario);
        btn_Voltar = findViewById(R.id.btn_Voltar);
        btn_Limpar = findViewById(R.id.btn_Limpar);
        btn_Excluir = findViewById(R.id.btn_Excluir);


        editTextEmailCadastroUsuario = findViewById(R.id.editTextEmailCadastroUsuario);
        editTextNomeCadastroUsuario = findViewById(R.id.editTextNomeCadastroUsuario);
        editTextSenhaCadastroUsuario = findViewById(R.id.editTextSenhaCadastroUsuario);
        editTextTelefoneCadastroUsuario = findViewById(R.id.editTextTelefoneCadastroUsuario);
        editTextTextLogin = findViewById(R.id.editTextTextLogin);


        listaUsuarios = findViewById(R.id.listaUsuarios);


        btn_Voltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentVoltar = new Intent(CadastroUsuario.this, MainActivity.class);
                startActivity(intentVoltar);
                finish();
            }
        });


        btn_Excluir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dtb.excluirUsuario(editTextTextLogin.getText().toString());
                Toast.makeText(getApplicationContext(), "Usuário excluido com sucesso", Toast.LENGTH_SHORT).show();
                atualizarLista();
                limparCampos();

            }
        });


        listaUsuarios.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                usuario = (CrudUsuario) parent.getAdapter().getItem(position);
                editTextNomeCadastroUsuario.setText(usuario.getNomeUsuario());
                editTextSenhaCadastroUsuario.setText(usuario.getSenha());
                editTextEmailCadastroUsuario.setText(usuario.getEmail());
                editTextTelefoneCadastroUsuario.setText(usuario.getContato());
                editTextTextLogin.setText(usuario.getLogin());

                btn_Excluir.setEnabled(true);
                editTextTextLogin.setEnabled(false);

                return false;
            }
        });

        atualizarLista();


        btn_CadastrarUsuario.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String operacao;
                if (usuario == null) {
                    operacao = "salvar";

                } else {
                    operacao = "editar";
                }

                usuario = new CrudUsuario();

                usuario.setNomeUsuario(editTextNomeCadastroUsuario.getText().toString());
                usuario.setSenha(editTextSenhaCadastroUsuario.getText().toString());
                usuario.setEmail(editTextEmailCadastroUsuario.getText().toString());
                usuario.setContato(editTextTelefoneCadastroUsuario.getText().toString());
                usuario.setLogin(editTextTextLogin.getText().toString());

                salvarUsuario(usuario, operacao);
            }
        });


    }

    public void salvarUsuario(CrudUsuario usuario, String operacao) {

        if (operacao.equals("salvar")) {
            dtb.salvarUsuario(usuario);
            Toast.makeText(getApplicationContext(), "Usuário salvo com sucesso", Toast.LENGTH_SHORT).show();
        } else {
            dtb.editarUsuario(usuario);
            Toast.makeText(getApplicationContext(), "Usuario editado com sucesso", Toast.LENGTH_SHORT).show();

        }
        atualizarLista();
        limparCampos();
    }


    public void limparCampos() {
        editTextNomeCadastroUsuario.setText("");
        editTextSenhaCadastroUsuario.setText("");
        editTextTelefoneCadastroUsuario.setText("");
        editTextEmailCadastroUsuario.setText("");
        editTextTextLogin.setText("");

        usuario = null;
        editTextTextLogin.setEnabled(true);
        btn_Excluir.setEnabled(false);

    }

    public void atualizarLista() {
        ArrayAdapter<CrudUsuario> adaptador = new ArrayAdapter<>(
                getApplicationContext(),
                android.R.layout.simple_list_item_1,
                android.R.id.text1,
                dtb.listarUsuarios()
        );


        listaUsuarios.setAdapter(adaptador);
    }
}