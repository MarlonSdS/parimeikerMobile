package univs.com.br.app.atividade.teste;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class CadastroUsuario extends AppCompatActivity {
    private Button btn_CadastrarUsuario;
    private EditText editTextEmailCadastroUsuario, editTextTelefoneCadastroUsuario, editTextSenhaCadastroUsuario, editTextNomeCadastroUsuario;
    private TextView txtNomeCadastroUsuario, txtSenhaCadastroUsuario, txtTelefoneCadastroUsuario, txtEmailCadastroUsuario;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro_usuario);
        btn_CadastrarUsuario = findViewById(R.id.btn_CadastrarUsuario);
        editTextEmailCadastroUsuario = findViewById(R.id.editTextEmailCadastroUsuario);
        editTextNomeCadastroUsuario = findViewById(R.id.editTextNomeCadastroUsuario);
        editTextSenhaCadastroUsuario = findViewById(R.id.editTextSenhaCadastroUsuario);
        editTextTelefoneCadastroUsuario = findViewById(R.id.editTextTelefoneCadastroUsuario);
        txtEmailCadastroUsuario = findViewById(R.id.txtEmailCadastroUsuario);
        txtNomeCadastroUsuario = findViewById(R.id.txtNomeCadastroUsuario);
        txtSenhaCadastroUsuario = findViewById(R.id.txtSenhaCadastroUsuario);
        txtTelefoneCadastroUsuario = findViewById(R.id.txtTelefoneCadastroUsuario);
    }
}